from src.Simulator import Simulator

if __name__ == "__main__":
    simulator = Simulator('Fuzzy Traffic System')
    simulator.start()
